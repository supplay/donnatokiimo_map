import{D as t,a,R as o,j as e,b as s,A as r}from"./App-C-WXUfHh.js";t.configure(a);o.createRoot(document.getElementById("root")).render(e.jsx(s.StrictMode,{children:e.jsx(r,{})}));
